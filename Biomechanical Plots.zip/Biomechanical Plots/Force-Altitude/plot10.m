clear
clc


basePath = "C:\Users\najmehas\OneDrive - Chalmers\Courses\Digitalization in Sports\Project\Ski pole data Merged with Gear\";

% Subject IDs and conditions
subjects   = [3 8 15 19 22];
conditions = ["NR", "WR"];  



gearColors = containers.Map;
gearColors("2.0V") = [0.0 0.6 0.0];
gearColors("2.0H") = [0.8 0.0 0.0];
gearColors("3.0")  = [0.0 0.0 0.8];
gearColors("4.0")  = [0.9 0.5 0.0];
gearColors("0.0")  = [0.3 0.3 0.3];
defaultColor       = [0.6 0.6 0.6];


for si = 1:numel(subjects)
    subj = subjects(si);

    % New figure for this subject
    figure


    tl = tiledlayout(1, 2, "TileSpacing", "compact", "Padding", "compact");

t=title(tl, sprintf("Force and Altitude over Distance with Gear Segments_Subject %d_NR & WR", subj), ...
          "Interpreter", "none")
    
t.FontWeight = "bold";
    for ci = 1:numel(conditions)
        cond = conditions(ci);

       
        fileName = sprintf("BIA24-%d_%s_merged_with_gear.csv", subj, cond);
        filePath = fullfile(basePath, fileName);

        
        opts = detectImportOptions(filePath, "PreserveVariableNames", true);
        opts = setvaropts(opts, "Gear", "Type", "string");

        T = readtable(filePath, opts);

        
        distance = T.("ns1:DistanceMeters3");
        forceVal = T.f_tot_mean_n;
        altitude = T.("ns1:AltitudeMeters");

       
        gear = upper(regexprep(T.Gear, "\s+", ""));

        
        nexttile
        hold on

       
        yyaxis left
        set(gca, "YColor", "k")
        plot(distance, forceVal, "k", "LineWidth", 2.5)
        ylabel("Force (N)")

        yyaxis right
        set(gca, "YColor", "r")
        plot(distance, altitude, "r--", "LineWidth", 1.1)
        ylabel("Altitude (m)")

        xlabel("Distance (m)")
        title(sprintf("Subject %d %s", subj, cond), "Interpreter", "none")

        drawnow

      
        yyaxis left
        yl_left = ylim;

        yyaxis right
        yl_right = ylim;

        yBottom = min(yl_left(1), yl_right(1));

       
        yyaxis left
        cla

        for i = 1:length(distance) - 1
            g = gear(i);

            if isKey(gearColors, g)
                c = gearColors(g);
            else
                c = defaultColor;
            end

            fill(...
                [distance(i) distance(i+1) distance(i+1) distance(i)], ...
                [yBottom yBottom forceVal(i+1) forceVal(i)], ...
                c, ...
                "EdgeColor", "none", "FaceAlpha", 0.35);
        end

        % Redraw curves
        yyaxis left
        plot(distance, forceVal, "k", "LineWidth", 2.5)

        yyaxis right
        plot(distance, altitude, "r--", "LineWidth", 1.1)

       
        if ci == 1
            uniqueGears = unique(gear, "stable");
            legendHandles = gobjects(length(uniqueGears) + 2, 1);
            legendEntries = strings(length(uniqueGears) + 2, 1);

            
            for j = 1:length(uniqueGears)
                g = uniqueGears(j);
                if isKey(gearColors, g)
                    c = gearColors(g);
                else
                    c = defaultColor;
                end
                legendHandles(j) = patch(nan, nan, c, "FaceAlpha", 0.35);
                legendEntries(j) = "Gear " + g;
            end

            k = length(uniqueGears);

            legendHandles(k+1) = plot(nan, nan, "k", "LineWidth", 2.5);
            legendEntries(k+1) = "Force";

            legendHandles(k+2) = plot(nan, nan, "r--", "LineWidth", 1.1);
            legendEntries(k+2) = "Altitude";

            legend(legendHandles, legendEntries, "Location", "bestoutside")
        end

        hold off
    end
end
