clear
clc


subjects = 1:22;

folderNR = "C:\Users\najmehas\OneDrive - Chalmers\Courses\Digitalization in Sports\Project\Ski pole data force_100Hz_Labeled1\downsampled_1Hz_NR";
folderWR = "C:\Users\najmehas\OneDrive - Chalmers\Courses\Digitalization in Sports\Project\Ski pole data force_100Hz_Labeled1\downsampled_1Hz_WR";

% columns: 1 = V left, 2 = V right, 3 = H left, 4 = H right
avg_NR = processFolder(folderNR, subjects, "NR");
avg_WR = processFolder(folderWR, subjects, "WR");


figure
tl = tiledlayout(1, 2, "TileSpacing", "compact", "Padding", "compact");

% Colors
col_V_left  = [0.6 1.0 0.6];
col_V_right = [0.0 0.5 0.0];
col_H_left  = [1.0 0.6 0.6];
col_H_right = [0.6 0.0 0.0];


nexttile
b1 = bar(subjects, avg_NR, "grouped");
b1(1).FaceColor = col_V_left;
b1(2).FaceColor = col_V_right;
b1(3).FaceColor = col_H_left;
b1(4).FaceColor = col_H_right;

xlabel("Subject number")
ylabel("Average force (N)")
title("NR condition")
xticks(subjects)
legend("2.0V left", "2.0V right", "2.0H left", "2.0H right")



nexttile
b2 = bar(subjects, avg_WR, "grouped");
b2(1).FaceColor = col_V_left;
b2(2).FaceColor = col_V_right;
b2(3).FaceColor = col_H_left;
b2(4).FaceColor = col_H_right;

xlabel("Subject number")
ylabel("Average force (N)")
title("WR condition")
xticks(subjects)



t = title(tl, "Average Left and Right forces for 2.0V and 2.0H Gears\_NR & WR");
t.FontWeight = "bold";

function avg_forces = processFolder(folder, subjects, tag)

    avg_forces = nan(length(subjects), 4);

    files = dir(fullfile(folder, "BIA24-*" + tag + "_1hz.csv"));

    for k = 1:length(files)

        fname = files(k).name;
        fullPath = fullfile(files(k).folder, fname);

        tokens = regexp(fname, "BIA24-(\d+)" + tag + "_1hz", "tokens");
        if isempty(tokens)
            continue
        end
        subjectID = str2double(tokens{1}{1});

        if ~ismember(subjectID, subjects)
            continue
        end

        opts = detectImportOptions(fullPath, "PreserveVariableNames", true);
        opts = setvaropts(opts, "Gear", "Type", "string");
        T = readtable(fullPath, opts);

        gearStr = upper(regexprep(T.Gear, "\s+", ""));
        fL = toNumeric(T.force_left_n);
        fR = toNumeric(T.force_right_n);

        idxV = contains(gearStr, "2.0V");
        idxH = contains(gearStr, "2.0H");

        mean_V_left  = mean(fL(idxV), "omitnan");
        mean_V_right = mean(fR(idxV), "omitnan");
        mean_H_left  = mean(fL(idxH), "omitnan");
        mean_H_right = mean(fR(idxH), "omitnan");

        row = find(subjects == subjectID);
        avg_forces(row, :) = [mean_V_left, mean_V_right, mean_H_left, mean_H_right];
    end
end


function x = toNumeric(col)
    if isnumeric(col)
        x = col;
    else
        s = string(col);
        s = strtrim(s);
        s = strrep(s, " ", "");
        s = strrep(s, ",", ".");
        x = str2double(s);
    end
end
