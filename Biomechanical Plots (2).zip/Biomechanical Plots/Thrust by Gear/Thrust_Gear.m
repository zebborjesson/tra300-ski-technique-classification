% ==============================
%  Boxplot of Mean Thrust vs Gear for WR and NR conditions
% ==============================
folder = "C:\Users\najmehas\OneDrive - Chalmers\Courses\Digitalization in Sports\Project\Ski pole data Merged with Gear";

% Define states
states = ["NR", "WR"];


validGears = [2, 3, 4,0];


gearColors = [ ...
    0.3 0.7 0.9;  % Gear 2 - light blue
    0.5 0.8 0.5;  % Gear 3 - greenish
    0.9 0.8 0.4;  % Gear 4 - yellow
    0.9 0.5 0.5]; % Gear 0 - carol


fig = figure;
fig.Units = "pixels";
fig.Position = [200 200 1800 900];  
t = tiledlayout(1,2, "TileSpacing","compact", "Padding","loose");


for s = 1:length(states)
    state = states(s);

    
    files = dir(fullfile(folder, sprintf('*_%s_merged_with_gear*.csv', state)));

    allThrust = [];
    allGear = [];

    % --- Loop through all files ---
    for f = 1:length(files)
        filepath = fullfile(folder, files(f).name);

        try
        
            opts = detectImportOptions(filepath);
            opts.VariableNamingRule = 'preserve';
            data = readtable(filepath, opts);

            % Normalize column names
            cols = lower(strtrim(data.Properties.VariableNames));
            idxL = find(strcmp(cols, 'thrust_left_ms'), 1);
            idxR = find(strcmp(cols, 'thrust_right_ms'), 1);
            idxGear = find(strcmp(cols, 'gear'), 1);

           
            if isempty(idxL) || isempty(idxR) || isempty(idxGear)
                fprintf('Skipping %s (missing required columns)\n', files(f).name);
                continue;
            end

         
            thrustL = data.(data.Properties.VariableNames{idxL});
            thrustR = data.(data.Properties.VariableNames{idxR});
            gearRaw = string(data.(data.Properties.VariableNames{idxGear}));

            
            gearRaw = upper(strtrim(gearRaw));
            gearRaw = replace(gearRaw, ",", ".");
            gearRaw = regexprep(gearRaw, '[^0-9A-Z\.]', '');

            % Convert all variants of 2.* to numeric 2
            gears = zeros(size(gearRaw));
            for i = 1:numel(gearRaw)
                if contains(gearRaw(i), "2")
                    gears(i) = 2;
                elseif contains(gearRaw(i), "3")
                    gears(i) = 3;
                elseif contains(gearRaw(i), "4")
                    gears(i) = 4;
                elseif contains(gearRaw(i), "0")
                    gears(i) = 0;
                else
                    gears(i) = NaN;
                end
            end

            % Compute mean thrust per row (average of left/right)
            thrustMean = mean([thrustL, thrustR], 2, 'omitnan');

            % Filter valid data
            validIdx = ~isnan(thrustMean) & ismember(gears, validGears);
            if any(validIdx)
                allThrust = [allThrust; thrustMean(validIdx)];
                allGear = [allGear; gears(validIdx)];
            end

        catch ME
            fprintf('Error reading %s: %s\n', files(f).name, ME.message);
        end
    end

    nexttile;

    
    if isempty(allThrust)
        title(sprintf('%s Condition (No Valid Data)', state));
        axis off;
        continue;
    end

  
    allGearCat = categorical(allGear, validGears, string(validGears));  % enforce order
    boxplot(allThrust, allGearCat, 'Colors', 'k', 'Notch', 'on', 'Symbol', 'r+');
   
    hold on;

  h = findobj(gca, 'Tag', 'Box');

for j = 1:length(h)
    x = mean(get(h(j), 'XData'));     
    idx = round(x);                  

    if idx >= 1 && idx <= size(gearColors,1)
        patch(get(h(j), 'XData'), get(h(j), 'YData'), gearColors(idx,:), ...
            'FaceAlpha', 0.6, 'EdgeColor', 'none');
    end
end

    %Compute mean ± SD per gear
    means = zeros(1, length(validGears));
sds   = zeros(1, length(validGears));

for i = 1:length(validGears)
    g = validGears(i);
    vals = allThrust(allGear == g);
    means(i) = mean(vals, 'omitnan');
    sds(i)   = std(vals, 'omitnan');
end

   errorbar(1:length(validGears), means, sds, 'ko', ...
    'MarkerFaceColor', 'k', 'MarkerSize', 7, 'LineWidth', 2, 'CapSize', 8);

   for i = 1:length(validGears)
    text(i + 0.15, means(i), sprintf('%.2f ± %.2f', means(i), sds(i)), ...
        'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
        'FontSize', 10, 'FontWeight', 'bold', 'Color', 'k');
end

   
    t1=title(sprintf('%s Condition', state));
    t1.FontSize=t1.FontSize*1.8;
    t1.FontWeight="bold";
    x1=xlabel('Gear');
    x1.FontSize=x1.FontSize*2;
    y1=ylabel('Mean Thrust (ms)');
    y1.FontSize=y1.FontSize*2;
   xticks(1:length(validGears));
    xticklabels(string(validGears));
    ax = gca;
ax.XAxis.FontSize = ax.XAxis.FontSize * 1.8;   
ax.XAxis.FontWeight = 'bold';
ax.YAxis.FontSize = ax.YAxis.FontSize * 1.8;
ax.YAxis.FontWeight = 'bold';
    grid on;
end

h=sgtitle('Boxplot of Mean Thrust by Gear with Mean ± SD\_ NR & WR');
h.FontWeight = 'bold';
h.FontSize=h.FontSize*2;

   fileOut = "Thrust_Gear1.jpg";
    exportgraphics(t, fileOut, "Resolution", 500);
