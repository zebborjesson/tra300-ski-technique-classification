
folder = "C:\Users\najmehas\OneDrive - Chalmers\Courses\Digitalization in Sports\Project\Ski pole data Merged with Gear";


states = ["NR", "WR"];


validGears = [2, 3, 4,0];


gearColors = [ ...
    0.3 0.7 0.9;  % Gear 2 - light blue
    0.5 0.8 0.5;  % Gear 3 - greenish
    0.9 0.8 0.4;  % Gear 4 - yellow
    0.9 0.5 0.5]; % Gear 0 - carol

fig = figure;
fig.Units = "pixels";
fig.Position = [200 200 1800 900];  
t = tiledlayout(1,2, "TileSpacing","loose", "Padding","loose");

for s = 1:length(states)
    state = states(s);

    
    files = dir(fullfile(folder, sprintf('*_%s_merged_with_gear*.csv', state)));

    allSpeed = [];
    allGear = [];

    for f = 1:length(files)
        filepath = fullfile(folder, files(f).name);
        try
            data = readtable(filepath);

            % Normalize column names
            cols = lower(strtrim(data.Properties.VariableNames));
            idxSpeed = find(strcmp(cols, 'speed_kmph'));
            idxGear = find(strcmp(cols, 'gear'));

            if ~isempty(idxSpeed) && ~isempty(idxGear)
                speed = data.(data.Properties.VariableNames{idxSpeed});
                gearRaw = string(data.(data.Properties.VariableNames{idxGear}));

                %Clean Gear strings (handle "2.0V", "2.0H", etc.) 
                gearClean = regexprep(gearRaw, ',', '.');
                gearClean = regexprep(gearClean, '\s', '');
                gearClean = regexprep(gearClean, '[^0-9]', '');
                gears = str2double(gearClean);

                % Keep valid data only
                validIdx = ~isnan(speed) & ismember(gears, validGears);
                gears = gears(validIdx);
                speeds = speed(validIdx);

                allSpeed = [allSpeed; speeds];
                allGear = [allGear; gears];
            end
        catch ME
            fprintf('Error reading %s: %s\n', files(f).name, ME.message);
        end
    end

    nexttile;

    if isempty(allSpeed)
        title(sprintf('%s Condition (No Data)', state));
        axis off;
        continue;
    end

   
    allGearCat = categorical(allGear, validGears, string(validGears));

    
    boxplot(allSpeed, allGearCat, 'Colors', 'k', 'Notch', 'on', 'Symbol', 'r+');
    hold on;

   
    h = findobj(gca, 'Tag', 'Box');
    for j = 1:length(h)
        gearIdx = length(h) - j + 1; % boxes stored right-to-left
        patch(get(h(j), 'XData'), get(h(j), 'YData'), gearColors(gearIdx, :), ...
              'FaceAlpha', 0.6, 'EdgeColor', 'none');
    end

    % Compute mean ± SD 
    means = [];
    sds = [];
    for g = validGears
        vals = allSpeed(allGear == g);
        means(end+1) = mean(vals, 'omitnan');
        sds(end+1) = std(vals, 'omitnan');
    end

   
    errorbar(1:length(validGears), means, sds, 'ko', ...
        'MarkerFaceColor', 'k', 'MarkerSize', 7, 'LineWidth', 2, 'CapSize', 8);

    for i = 1:length(validGears)
        if ~isnan(means(i))
            text(i + 0.15, means(i), ...
    sprintf('%.2f ± %.2f', means(i), sds(i)), ...
    'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
    'FontSize', 10, 'Color', 'k', 'FontWeight', 'bold');
        else
            text(i + 0.15, 0, 'No data', ...
                'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle', ...
                'FontSize', 10, 'Color', 'k');
        end
    end

    
    t1=title(sprintf('%s Condition', state));
    t1.FontSize=t1.FontSize*1.8;
    t1.FontWeight="bold";
    x1=xlabel('Gear');
    x1.FontSize=x1.FontSize*2;
    y1=ylabel('Speed (km/h)');
    y1.FontSize=y1.FontSize*2;
    xticklabels(string(validGears));
    ax = gca;
ax.XAxis.FontSize = ax.XAxis.FontSize * 1.8;   
ax.XAxis.FontWeight = 'bold';
ax.YAxis.FontSize = ax.YAxis.FontSize * 1.8;
ax.YAxis.FontWeight = 'bold';
    grid on;
end

h=sgtitle('Boxplot of Speed by Gear with Mean ± SD\_ NR & WR');
h.FontWeight = 'bold';
h.FontSize=h.FontSize*2;

   fileOut = "Speed_Gear1.jpg";
    exportgraphics(t, fileOut, "Resolution", 500);