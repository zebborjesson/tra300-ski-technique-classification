clear
clc


basePath = "C:\Users\najmehas\OneDrive - Chalmers\Courses\Digitalization in Sports\Project\Ski pole data Merged with Gear\";

% Subject IDs and conditions
subjects   = [3 8 15 19 22];
conditions = ["NR", "WR"];  



gearColors = containers.Map;
gearColors("2.0V") = [0.0 0.6 0.0];
gearColors("2.0H") = [0.8 0.0 0.0];
gearColors("3.0")  = [0.0 0.0 0.8];
gearColors("4.0")  = [0.9 0.5 0.0];
gearColors("0.0")  = [0.3 0.3 0.3];
defaultColor       = [0.6 0.6 0.6];


for si = 1:numel(subjects)
    subj = subjects(si);

    % New figure for this subject
    fig = figure;
set(fig, "Units", "centimeters")
set(fig, "Position", [2 2 36 26])

    tl = tiledlayout(1, 2, "TileSpacing", "compact", "Padding", "compact");

tlTitle =title(tl, sprintf("Force and Altitude over Distance with Gear Segments_Subject %d_NR & WR", subj), ...
          "Interpreter", "none")
    tlTitle.FontSize = tlTitle.FontSize * 2;
    tlTitle.FontWeight = "bold";

    for ci = 1:numel(conditions)
        cond = conditions(ci);

       
        fileName = sprintf("BIA24-%d_%s_merged_with_gear.csv", subj, cond);
        filePath = fullfile(basePath, fileName);

        
        opts = detectImportOptions(filePath, "PreserveVariableNames", true);
        opts = setvaropts(opts, "Gear", "Type", "string");

        T = readtable(filePath, opts);

        
        distance = T.("ns1:DistanceMeters3");
        forceVal = T.f_tot_mean_n;
        altitude = T.("ns1:AltitudeMeters");

       
        gear = upper(regexprep(T.Gear, "\s+", ""));

        
        ax = nexttile;
        hold(ax, "on");

       
        yyaxis(ax, "left")
        ax.YColor = "k";
       
        plot(ax,distance, forceVal, "k", "LineWidth", 2.5)
        y1=ylabel(ax,"Force (N)");
        y1.FontSize = y1.FontSize * 2;

        yyaxis(ax, "right")
        ax.YColor = "r";
        plot(ax,distance, altitude, "r--", "LineWidth", 2)
        y2=ylabel(ax,"Altitude (m)");
        y2.FontSize = y2.FontSize * 2;

        x1=xlabel(ax,"Distance (m)");
        x1.FontSize = x1.FontSize * 2;
        t1=title(ax,sprintf("Subject %d %s", subj, cond), "Interpreter", "none");
t1.FontSize = t1.FontSize * 2;
        t1.FontWeight = "bold";
ax.FontSize = ax.FontSize * 2;
ax.FontWeight = "bold";

        drawnow

      
        yyaxis(ax, "left")
        yl_left = ylim(ax);
       

        yyaxis(ax, "right")
        yl_right = ylim(ax);


       yBottom = min(yl_left(1), yl_right(1));
       
        yyaxis(ax, "left")
        cla(ax)

        for i = 1:length(distance) - 1
            g = gear(i);

            if isKey(gearColors, g)
                c = gearColors(g);
            else
                c = defaultColor;
            end

            fill(...
                [distance(i) distance(i+1) distance(i+1) distance(i)], ...
                [yBottom yBottom forceVal(i+1) forceVal(i)], ...
                c, ...
                "EdgeColor", "none", "FaceAlpha", 0.35);
        end

        % Redraw curves
       yyaxis(ax, "left")
        plot(ax,distance, forceVal, "k", "LineWidth", 2.5)

        yyaxis right
        plot(ax,distance, altitude, "r--", "LineWidth", 2)

       ax.FontSize = ax.FontSize;      % already scaled
        ax.FontWeight = "bold";
        y1.FontSize = y1.FontSize;      % already scaled
        y2.FontSize = y2.FontSize;      % already scaled
        x1.FontSize = x1.FontSize;      % already scaled
        t1.FontSize = t1.FontSize;      % already scaled
        t1.FontWeight = "bold";

        if ci == 1
            uniqueGears = unique(gear, "stable");
            legendHandles = gobjects(length(uniqueGears) + 2, 1);
            legendEntries = strings(length(uniqueGears) + 2, 1);

            
            for j = 1:length(uniqueGears)
                g = uniqueGears(j);
                if isKey(gearColors, g)
                    c = gearColors(g);
                else
                    c = defaultColor;
                end
                legendHandles(j) = patch(nan, nan, c, "FaceAlpha", 0.35);
                legendEntries(j) = "Gear " + g;
            end

            k = length(uniqueGears);

            legendHandles(k+1) = plot(nan, nan, "k", "LineWidth", 2.5);
            legendEntries(k+1) = "Force";

            legendHandles(k+2) = plot(nan, nan, "r--", "LineWidth", 2);
            legendEntries(k+2) = "Altitude";

            lg = legend(legendHandles, legendEntries, "Location", "bestoutside");
            lg.FontSize = lg.FontSize * 1.3;
            lg.FontWeight = "bold";
        end

 hold(ax, "off");
    end
    drawnow;  % ensure layout is finalized before export
    fileOut = sprintf("Force Altitude%d.jpg", subj);
    exportgraphics(fig, fileOut, "Resolution", 500);
end
